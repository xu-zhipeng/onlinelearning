package com.yougong.chain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChainApplicationTests {

	@Test
	void contextLoads() {
	}

}

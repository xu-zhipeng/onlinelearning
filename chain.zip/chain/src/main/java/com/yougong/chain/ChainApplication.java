package com.yougong.chain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChainApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChainApplication.class, args);
	}

}
